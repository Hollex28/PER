Conjunto de datos de 100 clases y 512 dimensiones para evaluar PCA+LDA
